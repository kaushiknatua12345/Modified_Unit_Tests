package com.hyland.calculator;

import static org.junit.Assert.*;
import org.junit.Test;

public class HylandCalculatorTest {

	@Test
	public void Add_TwoIntegers()
	{		
		HylandCalculator subject = new HylandCalculator();		
		assertEquals(subject.Add(6, 5),11);
		assertEquals(subject.Add(6, 0),6);
		assertEquals(subject.Add(6, -5),1);
		assertEquals(subject.Add(-6, -5),-11);
	}
}
