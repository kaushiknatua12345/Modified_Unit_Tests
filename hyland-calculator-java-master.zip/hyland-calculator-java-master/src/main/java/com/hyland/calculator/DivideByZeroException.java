package com.hyland.calculator;

public class DivideByZeroException extends Exception {

}
