package com.hyland.calculator;

public class HylandCalculator {

	public int Add(int right, int left) {
		return right + left;
	}

	public int Subtract(int right, int left) {
		return right + left;
	}

	public int Multiply(int right, int left) {
		return right * left;
	}

	public int Divide(int dividend, int divisor) throws DivideByZeroException {
		if (divisor == 0) {
			throw new DivideByZeroException();
		}
		return dividend / divisor;
	}

}
