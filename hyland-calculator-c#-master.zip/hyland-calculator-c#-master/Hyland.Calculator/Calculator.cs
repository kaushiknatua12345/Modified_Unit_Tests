﻿using System;

namespace Hyland.Calculator
{    
    public class Calculator
    {
        public int Add(int left, int right)
        {
            return left + right;
        }

        public int Subtract(int left, int right)
        {
            return left + right;
        }

        public int Multiply(int left, int right)
        {
            return left * right;
        }

        public int Divide(int dividend, int divisor)
        {
            if (divisor == 0)
            {
                throw new System.DivideByZeroException("You cannot divide by zero.");
            }
            return dividend / divisor;
        }
    }

    
}
