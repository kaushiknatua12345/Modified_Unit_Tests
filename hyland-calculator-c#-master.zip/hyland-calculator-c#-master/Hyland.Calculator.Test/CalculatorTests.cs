using NUnit.Framework;

namespace Hyland.Calculator.Test
{
    public class CalculatorTests
    {
        /// <summary>
        /// Verifies that adding two positive numbers using <see cref="Calculator.Add"/>
        /// will yield the correct value.
        /// </summary>
        [Test, Author("Kaushik Natua")]
        public void Add__TwoIntegers()
        {
            // Arrange.
            Calculator subject = new Calculator();

            // Act.
            int result = subject.Add(5,6);

            // Assert.
            Assert.That(result, Is.EqualTo(11));            
        }
    }
}